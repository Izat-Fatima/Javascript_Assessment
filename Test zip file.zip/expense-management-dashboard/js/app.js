(() => {
  "use strict";

  const STORAGE_KEY = "expense_manager_expenses_v1";
  const CATEGORIES = ["Food", "Transport", "Shopping", "Bills", "Other"];

  const $ = (selector) => document.querySelector(selector);

  const elements = {
    total: $("#totalExpenses"),
    month: $("#monthExpenses"),
    average: $("#averageExpense"),
    tableBody: $("#expenseTableBody"),
    resultCount: $("#resultCount"),
    emptyState: $("#emptyState"),
    message: $("#message"),
    search: $("#searchInput"),
    categoryFilter: $("#categoryFilter"),
    sort: $("#sortSelect"),
    modal: $("#expenseModal"),
    modalTitle: $("#modalTitle"),
    form: $("#expenseForm"),
    id: $("#expenseId"),
    title: $("#title"),
    category: $("#category"),
    amount: $("#amount"),
    date: $("#date"),
    description: $("#description")
  };

  let expenses = loadExpenses();

  function loadExpenses() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) throw new Error("Stored data is invalid.");
      return parsed.filter(isValidStoredExpense);
    } catch (error) {
      console.error(error);
      showMessage("Could not load saved expenses. Starting with an empty list.");
      return [];
    }
  }

  function isValidStoredExpense(item) {
    return item && typeof item === "object" &&
      typeof item.id === "string" &&
      typeof item.title === "string" &&
      CATEGORIES.includes(item.category) &&
      Number.isFinite(Number(item.amount)) &&
      typeof item.date === "string";
  }

  function saveExpenses() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(expenses));
      return true;
    } catch (error) {
      console.error(error);
      showMessage("Unable to save data in localStorage.");
      return false;
    }
  }

  function formatCurrency(value) {
    return new Intl.NumberFormat("en-US", {
      style: "currency", currency: "USD"
    }).format(Number(value) || 0);
  }

  function formatDate(date) {
    const d = new Date(`${date}T00:00:00`);
    return Number.isNaN(d.getTime()) ? date : d.toLocaleDateString();
  }

  function currentMonthTotal() {
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth();
    return expenses
      .filter(e => {
        const d = new Date(`${e.date}T00:00:00`);
        return d.getFullYear() === year && d.getMonth() === month;
      })
      .reduce((sum, e) => sum + Number(e.amount), 0);
  }

  function updateSummary() {
    const total = expenses.reduce((sum, e) => sum + Number(e.amount), 0);
    const average = expenses.length ? total / expenses.length : 0;
    elements.total.textContent = formatCurrency(total);
    elements.month.textContent = formatCurrency(currentMonthTotal());
    elements.average.textContent = formatCurrency(average);
  }

  function getVisibleExpenses() {
    const query = elements.search.value.trim().toLowerCase();
    const category = elements.categoryFilter.value;
    const sort = elements.sort.value;

    let result = expenses.filter(e => {
      const matchesTitle = e.title.toLowerCase().includes(query);
      const matchesCategory = category === "All" || e.category === category;
      return matchesTitle && matchesCategory;
    });

    result.sort((a, b) => {
      switch (sort) {
        case "amount-asc": return Number(a.amount) - Number(b.amount);
        case "amount-desc": return Number(b.amount) - Number(a.amount);
        case "date-asc": return a.date.localeCompare(b.date);
        case "title-asc": return a.title.localeCompare(b.title);
        case "title-desc": return b.title.localeCompare(a.title);
        case "date-desc":
        default: return b.date.localeCompare(a.date);
      }
    });
    return result;
  }

  function render() {
    updateSummary();
    const visible = getVisibleExpenses();
    elements.tableBody.innerHTML = "";

    elements.resultCount.textContent =
      `${visible.length} expense${visible.length === 1 ? "" : "s"}`;

    elements.emptyState.classList.toggle("hidden", visible.length !== 0);

    visible.forEach(expense => {
      const row = document.createElement("tr");

      row.innerHTML = `
        <td><strong>${escapeHtml(expense.title)}</strong></td>
        <td>${escapeHtml(expense.category)}</td>
        <td class="amount">${formatCurrency(expense.amount)}</td>
        <td>${escapeHtml(formatDate(expense.date))}</td>
        <td>${escapeHtml(expense.description || "—")}</td>
        <td>
          <div class="actions">
            <button class="small-btn" data-action="edit" data-id="${expense.id}">Edit</button>
            <button class="small-btn delete" data-action="delete" data-id="${expense.id}">Delete</button>
          </div>
        </td>`;
      elements.tableBody.appendChild(row);
    });
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function openModal(expense = null) {
    elements.form.reset();
    clearErrors();
    elements.id.value = expense?.id || "";
    elements.modalTitle.textContent = expense ? "Edit Expense" : "Add Expense";

    if (expense) {
      elements.title.value = expense.title;
      elements.category.value = expense.category;
      elements.amount.value = expense.amount;
      elements.date.value = expense.date;
      elements.description.value = expense.description || "";
    } else {
      elements.date.value = todayString();
    }

    elements.modal.classList.remove("hidden");
    elements.title.focus();
  }

  function closeModal() {
    elements.modal.classList.add("hidden");
    clearErrors();
  }

  function todayString() {
    const now = new Date();
    const offset = now.getTimezoneOffset();
    return new Date(now.getTime() - offset * 60000).toISOString().slice(0, 10);
  }

  function setError(id, text) {
    $(`#${id}Error`).textContent = text;
  }

  function clearErrors() {
    ["title", "category", "amount", "date", "description"].forEach(id => setError(id, ""));
  }

  function validateForm() {
    clearErrors();
    let valid = true;

    const title = elements.title.value.trim();
    const category = elements.category.value;
    const amount = Number(elements.amount.value);
    const date = elements.date.value;
    const description = elements.description.value.trim();

    if (!title) { setError("title", "Title is required."); valid = false; }
    if (!CATEGORIES.includes(category)) { setError("category", "Choose a valid category."); valid = false; }
    if (!Number.isFinite(amount) || amount <= 0) { setError("amount", "Amount must be greater than 0."); valid = false; }
    if (!date) { setError("date", "Date is required."); valid = false; }
    if (description.length > 250) { setError("description", "Maximum 250 characters."); valid = false; }

    return valid ? { title, category, amount: Number(amount.toFixed(2)), date, description } : null;
  }

  function submitExpense(event) {
    event.preventDefault();
    const data = validateForm();
    if (!data) return;

    const id = elements.id.value;

    if (id) {
      const index = expenses.findIndex(e => e.id === id);
      if (index !== -1) expenses[index] = { id, ...data };
    } else {
      expenses.push({ id: crypto.randomUUID(), ...data });
    }

    if (saveExpenses()) {
      closeModal();
      render();
      showMessage(id ? "Expense updated successfully." : "Expense added successfully.");
    }
  }

  function deleteExpense(id) {
    const expense = expenses.find(e => e.id === id);
    if (!expense) return;

    const confirmed = window.confirm(
      `Delete "${expense.title}"? This action cannot be undone.`
    );
    if (!confirmed) return;

    expenses = expenses.filter(e => e.id !== id);
    if (saveExpenses()) {
      render();
      showMessage("Expense deleted successfully.");
    }
  }

  function showMessage(text) {
    elements.message.textContent = text;
    elements.message.classList.remove("hidden");
    window.clearTimeout(showMessage.timer);
    showMessage.timer = window.setTimeout(() => {
      elements.message.classList.add("hidden");
    }, 3000);
  }

  $("#addExpenseBtn").addEventListener("click", () => openModal());
  $("#closeModalBtn").addEventListener("click", closeModal);
  $("#cancelBtn").addEventListener("click", closeModal);
  elements.form.addEventListener("submit", submitExpense);

  [elements.search, elements.categoryFilter, elements.sort]
    .forEach(el => el.addEventListener("input", render));

  elements.tableBody.addEventListener("click", event => {
    const button = event.target.closest("button[data-action]");
    if (!button) return;

    const expense = expenses.find(e => e.id === button.dataset.id);
    if (!expense) return;

    if (button.dataset.action === "edit") openModal(expense);
    if (button.dataset.action === "delete") deleteExpense(expense.id);
  });

  elements.modal.addEventListener("click", event => {
    if (event.target === elements.modal) closeModal();
  });

  document.addEventListener("keydown", event => {
    if (event.key === "Escape" && !elements.modal.classList.contains("hidden")) {
      closeModal();
    }
  });

  render();
})();