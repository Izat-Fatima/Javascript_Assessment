# Expense Management Dashboard

A responsive **vanilla JavaScript** Expense Management Dashboard built for the JavaScript Intern Assessment.

## Features

- Add, edit and delete expenses
- Expense fields: ID, title, category, amount, date and description
- Categories: Food, Transport, Shopping, Bills and Other
- Total expenses
- Current-month expenses
- Average expense
- Search by title
- Filter by category
- Sort by amount, date or title
- Delete confirmation
- Form validation
- localStorage persistence
- Responsive layout
- Empty and error states
- Event delegation for table actions
- No React or external JavaScript libraries

## Project Structure

```text
expense-management-dashboard/
├── index.html
├── README.md
├── css/
│   └── style.css
└── js/
    └── app.js
```

## How to Run

### Option 1: Direct browser
Open `index.html` in a modern browser.

### Option 2: VS Code Live Server
1. Open the project folder in VS Code.
2. Install/use the Live Server extension if available.
3. Right-click `index.html`.
4. Select **Open with Live Server**.

No backend or npm installation is required.

## Data Storage

Expenses are saved in the browser's `localStorage` under:

```text
expense_manager_expenses_v1
```

Data remains after refreshing the page in the same browser.

## Validation

- Title is required.
- Category must be one of the allowed categories.
- Amount must be a number greater than zero.
- Date is required.
- Description is limited to 250 characters.

## Assumptions / Trade-offs

- Currency is displayed in USD because the assessment example uses `$`.
- localStorage is used because the assessment asks for browser persistence and does not require a backend.
- Data is stored as JSON.
- This is a single-page vanilla JavaScript application to keep the assessment easy to run and review.

## Known Limitations

- Data is local to the browser/device and is not synchronized between users.
- There is no authentication or server database.
- localStorage has limited storage capacity.
- Currency conversion is not implemented.
